#pragma once
#include "BasicIncludes.h"

class UIRenderer
{
public:

private:
};

