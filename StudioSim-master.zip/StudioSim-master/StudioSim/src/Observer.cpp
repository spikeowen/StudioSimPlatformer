#include "pch.h"

#include "Observer.h"
//
//Observer::Observer()
//{
//	ExampleSingleton::Instance()->Test();
//}
