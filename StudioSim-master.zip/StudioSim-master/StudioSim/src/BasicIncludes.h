#pragma once

// Include all the basic includes needed for most files here
#include "json.h"
#include "KeyEvent.h"
#include "CustomMaths.h"
#include "Log.h"


using namespace std;

//#define _3D_SHADER
#define _2D_SHADER