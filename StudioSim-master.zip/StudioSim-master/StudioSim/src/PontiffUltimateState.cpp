#include "pch.h"
#include "pch.h"

#include "PontiffUltimateState.h"
#include "Quack.h"
#include "JsonLoader.h"

PontiffUltimateState::PontiffUltimateState(MiniPontiff* pontiff) : PontiffState(pontiff)
{
	m_timer = 3.0f;
}

void PontiffUltimateState::Update(float deltaTime)
{	
	
}
