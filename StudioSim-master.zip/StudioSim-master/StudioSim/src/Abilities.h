#pragma once
#include "Enemy.h"

namespace QuackEngine {
	namespace Abilities {
		void RangedAttack();
	}
}
